
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Karray
 */
public class MainClass {
    public static void main(String[] args) {
        Joueur j1 = new Joueur(1.74f, 74.8f, 10, "Abdennour", "Aymen");
        Joueur j2 = new Joueur(1.68f, 168, 7, "Msekni", "Youssef");
        Joueur j3 = new Joueur(1.80f, 95, 1, "Ben mustapha", "Farouk");
        Entraineur ent = new Entraineur(25, 24, "Benzarti", "Faouzi");
        Entraineur ent2 = new Entraineur(15, 17, "Maaloul", "Nabil");
        
        Club myClub = new Club(5);
     
        myClub.ajouter(ent);  // myClub.supprimer(j2);
        myClub.ajouter(j1);
        myClub.ajouter(j2);
        myClub.ajouter(j3);
        myClub.ajouter(ent2);
           
        System.out.println("----");
        System.out.println(myClub);
        System.out.println(" ====== ");
        myClub.afficherTailles();
        try {
            myClub.moyennePoids();
        } catch (PoidsException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
