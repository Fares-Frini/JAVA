/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Karray
 */
public class Joueur extends Membre{
    private float taille;
    private float poids;


    public Joueur(float taille, float poids, int id, String nom, String prenom) {
        super(id, nom, prenom);
        this.taille = taille;
        this.poids = poids;
    }

    @Override
    public String toString() {
        return super.toString()+"Joueur{" + "taille=" + taille + ", poids=" + poids + '}';
    }

    public float getTaille() {
        return taille;
    }

    public void setTaille(float taille) {
        this.taille = taille;
    }

    public float getPoids() {
        return poids;
    }

    public void setPoids(float poids) {
        this.poids = poids;
    }
    
    
    
}
