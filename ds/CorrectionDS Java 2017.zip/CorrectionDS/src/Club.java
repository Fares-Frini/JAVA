/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Karray
 */
public class Club {

    private int code;
    public int nbCapacite = 0;
    private Membre[] myTab = new Membre[30];

    public Club() {
    }

    public Club(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Membre[] getMyTab() {
        return myTab;
    }

    public void setMyTab(Membre[] myTab) {
        this.myTab = myTab;
    }

    @Override
    public String toString() {
        String res;
        res = " Code Club: " + code + "\n";
        for (int i = 0; i < nbCapacite; i++) {

            if (myTab[i] instanceof Joueur) {
                res += "Joueur " + i + myTab[i];
            }
        }
        return res;
    }

    public void ajouter(Membre membre) {
        boolean res = false, res2 = false;
        int x = 0;
        for (int i = 0; i < nbCapacite; i++) {

            if ((myTab[i].equals(membre))) {
                res = true;
            }

        }
        for (int j = 0; j < nbCapacite; j++) {

            if (((myTab[j] instanceof Entraineur))) {
                res2 = true;
            }
        }

        if (membre instanceof Joueur) {
            if (res == false) {
                myTab[nbCapacite] = membre;
                nbCapacite++;
                System.out.println(membre.getNom() + " ajoute!");
            }
        }
        if (membre instanceof Entraineur) {
            if (res2 == false) {
                myTab[nbCapacite] = membre;
                nbCapacite++;
                System.out.println(membre.getNom() + " ajoute!");
            }
        }

    }

    public boolean chercherJoueur(Membre p) {
        for (int i = 0; i < nbCapacite; i++) {
            if (myTab[i].equals(p)) {
                return true;
            }
        }
        return false;
    }

    public void supprimer(Membre membre) {
        if (chercherJoueur(membre)) {
            for (int i = 0; i < nbCapacite; i++) {
                if (myTab[i].equals(membre)) {
                    for (int j = i; j < nbCapacite - 1; j++) {
                        myTab[j] = myTab[j + 1];//Décalage
                    }
                    nbCapacite--;
                    myTab[nbCapacite] = null;
                }
            }
        } else {
            System.err.println("Membre inexistant");
        }
    }

    public void afficherTailles() {

        for (int i = 0; i < nbCapacite; i++) {
            if (myTab[i] instanceof Joueur) {
                System.out.println(((Joueur) myTab[i]).getTaille());
            }
        }
    }

    public void supprimerJoueurs(String nom) {
        for (int i = 0; i < nbCapacite; i++) {
            if (myTab[i].getNom().equals(nom)) {
                supprimer(myTab[i]);
            }
        }
    }

    public float moyennePoids() throws PoidsException {
        float moy = 0;
        float somme = 0;
        int nb = 0;
        for (int i = 0; i < nbCapacite; i++) {
            if (myTab[i] instanceof Joueur) {
                somme += ((Joueur) myTab[i]).getPoids();
                nb++;
            } else {
                nb--;
            }
        }

        moy = somme / nb;
        if (moy > 80) {
            throw new PoidsException("Alerte Poids");
        }
        return moy;
    }

}
