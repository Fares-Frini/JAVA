/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Karray
 */
public class Entraineur extends Membre{
    private int nbAnnee;

   

    public Entraineur(int nbAnnee, int id, String nom, String prenom) {
        super(id, nom, prenom);
        this.nbAnnee = nbAnnee;
    }

    public int getNbAnnee() {
        return nbAnnee;
    }

    public void setNbAnnee(int nbAnnee) {
        this.nbAnnee = nbAnnee;
    }

    @Override
    public String toString() {
        return super.toString()+"Entraineur{" + "nbAnnee=" + nbAnnee + '}';
    }
    
   
}
