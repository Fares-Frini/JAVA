/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Houssem Eddine
 */
public class Test {

    public static void main(String[] args) {
        int value = 0;
        try {
            value = 1;
            value = compute(value);
            value = 2;
        } catch (ArithmeticException e) {
            value = value + 10;
        } catch (RuntimeException e) {
            value = value + 20;
        }
        System.out.println(value);
    }

    private static int compute(int value) {
        return value / (value - 1);
    }
}
