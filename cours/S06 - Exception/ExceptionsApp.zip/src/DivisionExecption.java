
import java.util.Scanner;


public class DivisionExecption {


     static  int x =20;
     static int y ;
          public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
            System.out.println(" Enter un entier");
             y = scanner.nextInt();
            System.out.println(x/y);
    }


}
